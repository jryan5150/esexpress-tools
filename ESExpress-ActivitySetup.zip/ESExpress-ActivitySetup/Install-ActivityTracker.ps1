<#
.SYNOPSIS
    ES Express Activity Tracker - One-Click Installer
.DESCRIPTION
    Downloads and installs ActivityWatch, deploys export scripts,
    creates scheduled tasks for automatic daily reports, and
    opens the Chrome Web Store for the browser extension.
.NOTES
    No admin required - ActivityWatch uses per-user installation.
    Requires PowerShell 5.1+ and internet access.
#>

# --- Configuration ----------------------------------------------------------

$INSTALL_DIR = "C:\ESExpress\ActivityTracker"
$ARCHIVE_DIR = "$INSTALL_DIR\archive"
$DESKTOP = [Environment]::GetFolderPath("Desktop")
$SCRIPT_DIR = Split-Path -Parent $MyInvocation.MyCommand.Path

$AW_GITHUB_API = "https://api.github.com/repos/ActivityWatch/activitywatch/releases/latest"
$AW_FALLBACK_URL = "https://github.com/ActivityWatch/activitywatch/releases/download/v0.13.2/activitywatch-v0.13.2-windows-x86_64-setup.exe"
$AW_INSTALLER_PATTERN = "activitywatch-*-windows-x86_64-setup.exe"

$CHROME_EXT_URL = "https://chromewebstore.google.com/detail/activitywatch-web-watcher/nglaklhklhcoonedhgnpgddginnjdadi"

# --- Helper Functions -------------------------------------------------------

function Write-Step {
    param([int]$Number, [string]$Label)
    Write-Host ""
    Write-Host "[$Number/7] $Label" -ForegroundColor Cyan
    Write-Host ("-" * 50) -ForegroundColor DarkGray
}

function Write-OK {
    param([string]$Message)
    Write-Host "  [OK] $Message" -ForegroundColor Green
}

function Write-Skip {
    param([string]$Message)
    Write-Host "  [>>] $Message" -ForegroundColor Yellow
}

function Write-Fail {
    param([string]$Message)
    Write-Host "  [!!] $Message" -ForegroundColor Red
}

# --- Banner -----------------------------------------------------------------

Write-Host ""
Write-Host "===================================================" -ForegroundColor White
Write-Host "  ES Express - Activity Tracker Installer" -ForegroundColor Cyan
Write-Host "===================================================" -ForegroundColor White
Write-Host ""
Write-Host "  This will install:" -ForegroundColor Gray
Write-Host "    * ActivityWatch (desktop activity tracker)" -ForegroundColor Gray
Write-Host "    * Chrome extension (web activity tracker)" -ForegroundColor Gray
Write-Host "    * Automatic daily report generation" -ForegroundColor Gray
Write-Host ""
Write-Host "  No admin required. Takes about 2 minutes." -ForegroundColor Gray
Write-Host ""

# --- Step 1: Preflight -----------------------------------------------------

Write-Step 1 "Preflight checks"

if ($PSVersionTable.PSVersion.Major -lt 5) {
    Write-Fail "PowerShell 5.1+ required. You have $($PSVersionTable.PSVersion)"
    Read-Host "Press Enter to exit"
    exit 1
}
Write-OK "PowerShell $($PSVersionTable.PSVersion)"

try {
    $null = Invoke-WebRequest -Uri "https://github.com" -UseBasicParsing -TimeoutSec 5 -ErrorAction Stop
    Write-OK "Internet connection"
} catch {
    Write-Fail "No internet connection. Please connect and try again."
    Read-Host "Press Enter to exit"
    exit 1
}

$awInstalled = $false
$awPaths = @(
    "$env:LOCALAPPDATA\Programs\activitywatch\aw-qt.exe",
    "$env:ProgramFiles\activitywatch\aw-qt.exe",
    "${env:ProgramFiles(x86)}\activitywatch\aw-qt.exe",
    "$env:LOCALAPPDATA\activitywatch\aw-qt.exe"
)
foreach ($p in $awPaths) {
    if (Test-Path $p) {
        $awInstalled = $true
        $awExePath = $p
        Write-Skip "ActivityWatch already installed at $p"
        break
    }
}
if (-not $awInstalled) {
    Write-OK "ActivityWatch not yet installed - will download"
}

# --- Step 2: Download and Install ActivityWatch -----------------------------

Write-Step 2 "Download and install ActivityWatch"

if ($awInstalled) {
    Write-Skip "Skipping - already installed"
} else {
    $downloadUrl = $null
    try {
        Write-Host "  Checking latest release..." -ForegroundColor Gray
        $release = Invoke-RestMethod -Uri $AW_GITHUB_API -TimeoutSec 10 -ErrorAction Stop
        $asset = $release.assets | Where-Object { $_.name -like $AW_INSTALLER_PATTERN } | Select-Object -First 1
        if ($asset) {
            $downloadUrl = $asset.browser_download_url
            Write-OK "Found release: $($release.tag_name)"
        }
    } catch {
        Write-Host "  GitHub API unavailable, using fallback URL" -ForegroundColor Yellow
    }

    if (-not $downloadUrl) {
        $downloadUrl = $AW_FALLBACK_URL
        Write-Host "  Using fallback: v0.13.2" -ForegroundColor Gray
    }

    $installerPath = Join-Path $env:TEMP "activitywatch-setup.exe"
    try {
        Write-Host "  Downloading (~81 MB)... this may take a minute" -ForegroundColor Gray
        Invoke-WebRequest -Uri $downloadUrl -OutFile $installerPath -UseBasicParsing -ErrorAction Stop
        Write-OK "Download complete"
    } catch {
        Write-Fail "Download failed: $_"
        Read-Host "Press Enter to exit"
        exit 1
    }

    Write-Host "  Installing..." -ForegroundColor Gray
    $installProcess = Start-Process -FilePath $installerPath -ArgumentList "/VERYSILENT /SUPPRESSMSGBOXES /TASKS=`"StartMenuEntry`"" -Wait -PassThru
    if ($installProcess.ExitCode -ne 0) {
        Write-Fail "Install failed with exit code $($installProcess.ExitCode)"
        Read-Host "Press Enter to exit"
        exit 1
    }
    Write-OK "ActivityWatch installed"

    foreach ($p in $awPaths) {
        if (Test-Path $p) {
            $awExePath = $p
            break
        }
    }

    Remove-Item $installerPath -Force -ErrorAction SilentlyContinue
}

# --- Step 3: Chrome Extension ----------------------------------------------

Write-Step 3 "Chrome browser extension"

Write-Host "  Opening Chrome Web Store..." -ForegroundColor Gray
Start-Process $CHROME_EXT_URL
Write-Host ""
Write-Host "  In your browser, click 'Add to Chrome' to install the extension." -ForegroundColor Yellow
Write-Host ""
Read-Host "  Press Enter here after you've added the extension"
Write-OK "Chrome extension step complete"

# --- Step 4: Employee Name -------------------------------------------------

Write-Step 4 "Set your name for reports"

$existingName = $env:AW_EMPLOYEE_NAME
if ($existingName) {
    Write-Host "  Current name: $existingName" -ForegroundColor Gray
    $changeName = Read-Host "  Keep this name? (Y/n)"
    if ($changeName -eq "n" -or $changeName -eq "N") {
        $existingName = $null
    }
}

if (-not $existingName) {
    $name = Read-Host "  Enter your first name (e.g., Jessica)"
    if (-not $name) {
        $name = $env:COMPUTERNAME
        Write-Host "  No name entered - using computer name: $name" -ForegroundColor Yellow
    }
    [Environment]::SetEnvironmentVariable("AW_EMPLOYEE_NAME", $name, "User")
    $env:AW_EMPLOYEE_NAME = $name
    Write-OK "Name set to: $name"
} else {
    Write-OK "Keeping name: $existingName"
}

# --- Step 5: Deploy Scripts ------------------------------------------------

Write-Step 5 "Deploy report scripts"

New-Item -ItemType Directory -Path $INSTALL_DIR -Force | Out-Null
New-Item -ItemType Directory -Path $ARCHIVE_DIR -Force | Out-Null
Write-OK "Created $INSTALL_DIR"

$scriptFiles = @(
    @{ Name = "Export-DailyActivity.ps1"; Dest = $INSTALL_DIR },
    @{ Name = "Export-My-Activity.bat"; Dest = $DESKTOP },
    @{ Name = "Review-TeamActivity.ps1"; Dest = $DESKTOP }
)

foreach ($sf in $scriptFiles) {
    $src = Join-Path $SCRIPT_DIR $sf.Name
    if (Test-Path $src) {
        Copy-Item $src -Destination $sf.Dest -Force
        Write-OK "$($sf.Name) -> $($sf.Dest)"
    } else {
        Write-Fail "$($sf.Name) not found - skipping"
    }
}

# --- Step 6: Create Scheduled Tasks ----------------------------------------

Write-Step 6 "Set up automatic daily reports"

$exportScript = Join-Path $INSTALL_DIR "Export-DailyActivity.ps1"

$taskName1 = "ESExpress Daily Activity Export"
$existingTask1 = Get-ScheduledTask -TaskName $taskName1 -ErrorAction SilentlyContinue
if ($existingTask1) {
    Unregister-ScheduledTask -TaskName $taskName1 -Confirm:$false
}

$action1 = New-ScheduledTaskAction `
    -Execute "powershell.exe" `
    -Argument "-ExecutionPolicy Bypass -WindowStyle Hidden -File `"$exportScript`" -Silent"

$trigger1 = New-ScheduledTaskTrigger -Daily -At "5:30PM"

$settings1 = New-ScheduledTaskSettingsSet `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries `
    -StartWhenAvailable

Register-ScheduledTask `
    -TaskName $taskName1 `
    -Action $action1 `
    -Trigger $trigger1 `
    -Settings $settings1 `
    -Description "Generates daily activity report on Desktop at 5:30 PM" | Out-Null

Write-OK "Scheduled: $taskName1 (daily at 5:30 PM)"

$taskName2 = "ESExpress Activity Catchup"
$existingTask2 = Get-ScheduledTask -TaskName $taskName2 -ErrorAction SilentlyContinue
if ($existingTask2) {
    Unregister-ScheduledTask -TaskName $taskName2 -Confirm:$false
}

$catchupScript = Join-Path $INSTALL_DIR "Catchup-ActivityExport.ps1"
$catchupContent = @'
# ESExpress Activity Catchup - runs on login
# Generates yesterday's report if it doesn't already exist

$DESKTOP = [Environment]::GetFolderPath("Desktop")
$INSTALL_DIR = "C:\ESExpress\ActivityTracker"
$empName = if ($env:AW_EMPLOYEE_NAME) { $env:AW_EMPLOYEE_NAME } else { $env:COMPUTERNAME }
$yesterday = (Get-Date).AddDays(-1).ToString("yyyy-MM-dd")
$reportPath = Join-Path $DESKTOP "activity-report-$empName-$yesterday.html"

if (-not (Test-Path $reportPath)) {
    $exportScript = Join-Path $INSTALL_DIR "Export-DailyActivity.ps1"
    if (Test-Path $exportScript) {
        & $exportScript -DateOverride $yesterday -Silent
    }
}
'@
$catchupContent | Out-File -FilePath $catchupScript -Encoding UTF8

$action2 = New-ScheduledTaskAction `
    -Execute "powershell.exe" `
    -Argument "-ExecutionPolicy Bypass -WindowStyle Hidden -File `"$catchupScript`""

$trigger2 = New-ScheduledTaskTrigger -AtLogon
$trigger2.Delay = "PT2M"

$settings2 = New-ScheduledTaskSettingsSet `
    -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries

Register-ScheduledTask `
    -TaskName $taskName2 `
    -Action $action2 `
    -Trigger $trigger2 `
    -Settings $settings2 `
    -Description "Generates yesterday's activity report on login if missing" | Out-Null

Write-OK "Scheduled: $taskName2 (on login, 2 min delay)"

# --- Step 7: Launch and Confirm --------------------------------------------

Write-Step 7 "Launch ActivityWatch"

if ($awExePath -and (Test-Path $awExePath)) {
    Start-Process $awExePath
    Write-OK "ActivityWatch started"
} else {
    Write-Skip "Could not find aw-qt.exe - please start ActivityWatch manually from the Start Menu"
}

$empName = if ($env:AW_EMPLOYEE_NAME) { $env:AW_EMPLOYEE_NAME } else { $env:COMPUTERNAME }

Write-Host ""
Write-Host "===================================================" -ForegroundColor White
Write-Host "  Setup Complete!" -ForegroundColor Green
Write-Host "===================================================" -ForegroundColor White
Write-Host ""
Write-Host "  What's installed:" -ForegroundColor Gray
Write-Host "    * ActivityWatch - tracking your desktop activity" -ForegroundColor Gray
Write-Host "    * Chrome extension - please verify it's added" -ForegroundColor Gray
Write-Host "    * Daily report - auto-generates at 5:30 PM" -ForegroundColor Gray
Write-Host "    * Login catch-up - fills in missed days" -ForegroundColor Gray
Write-Host ""
Write-Host "  Scripts deployed to:" -ForegroundColor Gray
Write-Host "    $INSTALL_DIR" -ForegroundColor White
Write-Host ""
Write-Host "  Reports appear on your Desktop as:" -ForegroundColor Gray
Write-Host "    activity-report-$empName-YYYY-MM-DD.html" -ForegroundColor White
Write-Host ""
Write-Host "  Reports older than 7 days auto-archive to:" -ForegroundColor Gray
Write-Host "    $ARCHIVE_DIR" -ForegroundColor White
Write-Host ""
Write-Host "  Manual export anytime: double-click" -ForegroundColor Gray
Write-Host "    Export-My-Activity.bat on your Desktop" -ForegroundColor White
Write-Host ""
Write-Host "  Questions? Contact Jace: JRyan@Lexcom.com" -ForegroundColor Gray
Write-Host ""
Read-Host "Press Enter to close this window"

ES Express Activity Tracker — Setup Package
============================================

WHAT THIS DOES:
Tracks which applications and websites you use during your work day
so we can validate and audit time entries. No keystrokes, no screenshots,
no screen recording. Data stays on your computer.

INSTALL (2 minutes):

  1. Double-click "Install-ActivityTracker.bat"
  2. Follow the prompts — it downloads and installs everything
  3. When it opens Chrome, click "Add to Chrome" for the extension
  4. Enter your first name when asked
  5. Done! Reports auto-generate daily at 5:30 PM on your Desktop

DAILY REPORTS:
  - An HTML report appears on your Desktop every day at 5:30 PM
  - If your computer was off, it catches up when you log in next
  - Reports older than 7 days are archived (not deleted)
  - To manually export anytime: double-click "Export-My-Activity.bat"

WHAT'S TRACKED:
  - Which applications are in the foreground (e.g., "Chrome", "Excel")
  - Which websites you visit (domain only, not page content)
  - Active vs. idle time

WHAT'S NOT TRACKED:
  - No keystrokes, no screenshots, no screen recording
  - No microphone, no camera, no file contents

QUESTIONS? Contact Jace: JRyan@Lexcom.com or (877) 539-2663

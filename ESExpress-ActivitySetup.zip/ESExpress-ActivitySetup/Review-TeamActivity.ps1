<#
.SYNOPSIS
    Jessica's Team Activity Review — aggregates daily reports from team members.
.DESCRIPTION
    Point this at a folder containing activity-report JSON files from the team.
    Produces a combined summary showing each employee's active time, top apps,
    and activity rate side by side.
.EXAMPLE
    .\Review-TeamActivity.ps1 -ReportFolder "C:\Users\Jessica\Desktop\team-reports"
    .\Review-TeamActivity.ps1   # Defaults to Desktop
#>

param(
    [string]$ReportFolder = [Environment]::GetFolderPath("Desktop"),
    [string]$Date = (Get-Date).ToString("yyyy-MM-dd")
)

Write-Host "ES Express Team Activity Review" -ForegroundColor Cyan
Write-Host "Looking for reports dated: $Date" -ForegroundColor Gray
Write-Host "Folder: $ReportFolder" -ForegroundColor Gray
Write-Host ""

# Find all JSON reports for the given date
$pattern = "activity-report-*-$Date.json"
$files = Get-ChildItem -Path $ReportFolder -Filter $pattern -ErrorAction SilentlyContinue

if ($files.Count -eq 0) {
    Write-Host "No reports found matching: $pattern" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Make sure team members have sent their report files to this folder." -ForegroundColor Gray
    Write-Host "Report files look like: activity-report-Scout-2026-03-30.json" -ForegroundColor Gray
    Read-Host "Press Enter to exit"
    exit 0
}

Write-Host "Found $($files.Count) report(s):" -ForegroundColor Green
$files | ForEach-Object { Write-Host "  $($_.Name)" }
Write-Host ""

# Parse and summarize each report
$teamData = @()
foreach ($file in $files) {
    $json = Get-Content $file.FullName -Raw | ConvertFrom-Json
    $teamData += @{
        Name = $json.employee
        ActiveTime = $json.summary.active_seconds
        IdleTime = $json.summary.idle_seconds
        TotalTime = $json.summary.total_seconds
        ActiveRate = $json.summary.active_rate
        TopApps = ($json.applications | Select-Object -First 5)
        TopSites = ($json.websites | Select-Object -First 5)
        Hourly = $json.hourly
    }
}

function Format-Dur {
    param([double]$Seconds)
    $ts = [TimeSpan]::FromSeconds($Seconds)
    if ($ts.TotalHours -ge 1) { return "{0}h {1}m" -f [int]$ts.TotalHours, $ts.Minutes }
    elseif ($ts.TotalMinutes -ge 1) { return "{0}m" -f [int]$ts.TotalMinutes }
    else { return "{0}s" -f [int]$ts.TotalSeconds }
}

# ─── Console Summary ─────────────────────────────────────────────────────────

Write-Host "═══════════════════════════════════════════════════" -ForegroundColor DarkGray
Write-Host " TEAM SUMMARY — $Date" -ForegroundColor White
Write-Host "═══════════════════════════════════════════════════" -ForegroundColor DarkGray
Write-Host ""
Write-Host ("{0,-15} {1,-12} {2,-12} {3,-12} {4,-10}" -f "Employee", "Active", "Idle", "Total", "Rate") -ForegroundColor Gray
Write-Host ("{0,-15} {1,-12} {2,-12} {3,-12} {4,-10}" -f "--------", "------", "----", "-----", "----") -ForegroundColor DarkGray

foreach ($emp in ($teamData | Sort-Object -Property { $_.ActiveRate } -Descending)) {
    $rateStr = "{0}%" -f [math]::Round($emp.ActiveRate * 100, 0)
    $rateColor = if ($emp.ActiveRate -ge 0.7) { "Green" } elseif ($emp.ActiveRate -ge 0.5) { "Yellow" } else { "Red" }
    Write-Host ("{0,-15} {1,-12} {2,-12} {3,-12}" -f $emp.Name, (Format-Dur $emp.ActiveTime), (Format-Dur $emp.IdleTime), (Format-Dur $emp.TotalTime)) -NoNewline
    Write-Host (" {0,-10}" -f $rateStr) -ForegroundColor $rateColor
}

Write-Host ""

# ─── Per-employee detail ─────────────────────────────────────────────────────

foreach ($emp in $teamData) {
    Write-Host "───────────────────────────────────────────────────" -ForegroundColor DarkGray
    Write-Host " $($emp.Name)" -ForegroundColor White
    Write-Host ""

    Write-Host "  Top Applications:" -ForegroundColor Cyan
    foreach ($app in $emp.TopApps) {
        Write-Host ("    {0,-30} {1}" -f $app.name, (Format-Dur $app.seconds))
    }
    Write-Host ""

    if ($emp.TopSites.Count -gt 0) {
        Write-Host "  Top Websites:" -ForegroundColor Cyan
        foreach ($site in $emp.TopSites) {
            Write-Host ("    {0,-30} {1}" -f $site.domain, (Format-Dur $site.seconds))
        }
        Write-Host ""
    }

    Write-Host "  Hourly Activity:" -ForegroundColor Cyan
    foreach ($hour in $emp.Hourly) {
        $h = $hour.hour
        $mins = [math]::Round($hour.active_seconds / 60, 0)
        $label = if ($h -lt 12) { "$h AM" } elseif ($h -eq 12) { "12 PM" } else { "$($h-12) PM" }
        $bar = "#" * [math]::Min([math]::Round($mins / 60 * 30, 0), 30)
        $color = if ($mins -ge 45) { "Green" } elseif ($mins -ge 20) { "Yellow" } else { "Red" }
        Write-Host ("    {0,-7}" -f $label) -NoNewline
        Write-Host ("{0,-32}" -f $bar) -ForegroundColor $color -NoNewline
        Write-Host (" {0} min" -f $mins)
    }
    Write-Host ""
}

# ─── Generate combined HTML ──────────────────────────────────────────────────

$empCards = ""
foreach ($emp in ($teamData | Sort-Object -Property { $_.ActiveRate } -Descending)) {
    $rateStr = "{0}%" -f [math]::Round($emp.ActiveRate * 100, 0)
    $rateColor = if ($emp.ActiveRate -ge 0.7) { "#22c55e" } elseif ($emp.ActiveRate -ge 0.5) { "#f59e0b" } else { "#ef4444" }

    $appList = ""
    foreach ($app in $emp.TopApps) {
        $appList += "<li>$($app.name) <span class='dim'>$(Format-Dur $app.seconds)</span></li>"
    }

    $siteList = ""
    foreach ($site in $emp.TopSites) {
        $siteList += "<li>$($site.domain) <span class='dim'>$(Format-Dur $site.seconds)</span></li>"
    }

    $hourBars = ""
    foreach ($hour in $emp.Hourly) {
        $h = $hour.hour
        $mins = [math]::Round($hour.active_seconds / 60, 0)
        $pct = [math]::Min([math]::Round($hour.active_seconds / 3600 * 100, 0), 100)
        $hColor = if ($mins -ge 45) { "#22c55e" } elseif ($mins -ge 20) { "#f59e0b" } else { "#ef4444" }
        $label = if ($h -lt 12) { "${h}a" } elseif ($h -eq 12) { "12p" } else { "$($h-12)p" }
        $hourBars += "<div class='hour-bar'><span class='hour-label'>$label</span><div class='bar-bg'><div class='bar' style='width:${pct}%;background:${hColor}'></div></div><span class='dim'>${mins}m</span></div>"
    }

    $empCards += @"
    <div class="emp-card">
        <div class="emp-header">
            <h3>$($emp.Name)</h3>
            <div class="rate" style="color:$rateColor">$rateStr active</div>
        </div>
        <div class="emp-stats">
            <span>Active: <strong>$(Format-Dur $emp.ActiveTime)</strong></span>
            <span>Idle: <strong>$(Format-Dur $emp.IdleTime)</strong></span>
            <span>Total: <strong>$(Format-Dur $emp.TotalTime)</strong></span>
        </div>
        <div class="emp-timeline">$hourBars</div>
        <div class="emp-detail">
            <div><h4>Top Apps</h4><ul>$appList</ul></div>
            <div><h4>Top Sites</h4><ul>$siteList</ul></div>
        </div>
    </div>
"@
}

$combinedHtml = @"
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Team Activity Review — $Date</title>
<style>
    body { font-family: 'Segoe UI', Tahoma, sans-serif; max-width: 1000px; margin: 40px auto; padding: 0 20px; background: #0f172a; color: #e2e8f0; }
    h1 { color: #f8fafc; }
    h3 { margin: 0; color: #f8fafc; }
    h4 { color: #94a3b8; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px; margin: 12px 0 6px; }
    .emp-card { background: #1e293b; border-radius: 12px; padding: 20px; margin: 16px 0; }
    .emp-header { display: flex; justify-content: space-between; align-items: center; }
    .rate { font-size: 24px; font-weight: 700; }
    .emp-stats { display: flex; gap: 24px; margin: 12px 0; color: #94a3b8; font-size: 14px; }
    .emp-stats strong { color: #e2e8f0; }
    .emp-timeline { margin: 12px 0; }
    .hour-bar { display: flex; align-items: center; gap: 8px; margin: 2px 0; }
    .hour-label { width: 30px; font-size: 11px; color: #64748b; text-align: right; }
    .bar-bg { flex: 1; height: 10px; background: #0f172a; border-radius: 5px; }
    .bar { height: 100%; border-radius: 5px; }
    .emp-detail { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
    .emp-detail ul { list-style: none; padding: 0; margin: 0; }
    .emp-detail li { padding: 3px 0; font-size: 13px; }
    .dim { color: #64748b; }
    .footer { margin-top: 40px; color: #475569; font-size: 12px; border-top: 1px solid #334155; padding-top: 12px; }
</style>
</head>
<body>

<h1>Team Activity Review</h1>
<p class="dim">$Date | $($teamData.Count) employee(s)</p>

$empCards

<div class="footer">
    Generated by ES Express Activity Review on $(Get-Date -Format "yyyy-MM-dd HH:mm")
</div>

</body>
</html>
"@

$combinedFile = Join-Path $ReportFolder "team-review-$Date.html"
$combinedHtml | Out-File -FilePath $combinedFile -Encoding UTF8
Write-Host "Combined HTML report: $combinedFile" -ForegroundColor Green

Start-Process $combinedFile

Write-Host ""
Read-Host "Press Enter to exit"

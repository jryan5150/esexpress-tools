@echo off
REM ES Express — Activity Tracker Installer
REM Double-click this file to install ActivityWatch and configure reports.
powershell.exe -ExecutionPolicy Bypass -File "%~dp0Install-ActivityTracker.ps1"

@echo off
REM ES Express — Activity Tracker Installer
REM Double-click this file to install ActivityWatch and configure reports.

REM Unblock scripts downloaded from the internet (removes Zone.Identifier mark)
powershell.exe -ExecutionPolicy Bypass -Command "Get-ChildItem -Path '%~dp0' -Filter '*.ps1' | Unblock-File -ErrorAction SilentlyContinue"

REM Run the installer
powershell.exe -ExecutionPolicy Bypass -File "%~dp0Install-ActivityTracker.ps1"

REM Safety net — keep window open if the script crashed before its own pause
if %ERRORLEVEL% neq 0 (
    echo.
    echo Something went wrong. Error code: %ERRORLEVEL%
    echo Contact Jace: JRyan@Lexcom.com or 903-363-4576
    pause
)

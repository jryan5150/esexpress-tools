@echo off
REM ES Express — Daily Activity Export
REM Double-click this file at end of day to generate your report.
powershell.exe -ExecutionPolicy Bypass -File "%~dp0Export-DailyActivity.ps1"

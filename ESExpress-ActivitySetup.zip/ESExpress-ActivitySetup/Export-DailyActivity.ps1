<#
.SYNOPSIS
    ES Express Daily Activity Export
.DESCRIPTION
    Pulls activity data from the local ActivityWatch instance and generates
    an HTML report for review. Run this at the end of each work day.
.NOTES
    Requires ActivityWatch running locally on port 5600.
    No other dependencies — pure PowerShell.
#>

param(
    [string]$DateOverride,
    [switch]$Silent
)

# ─── Configuration ───────────────────────────────────────────────────────────

$AW_BASE_URL = "http://localhost:5600/api/0"
$EMPLOYEE_NAME = $env:COMPUTERNAME  # Default to computer name; override below
$REPORT_DIR = [Environment]::GetFolderPath("Desktop")
$WORK_START_HOUR = 6   # 6 AM
$WORK_END_HOUR = 20    # 8 PM

# Override employee name if set
if ($env:AW_EMPLOYEE_NAME) {
    $EMPLOYEE_NAME = $env:AW_EMPLOYEE_NAME
}

# Date to export (default: today)
$ExportDate = Get-Date
if ($DateOverride -and $DateOverride -match '^\d{4}-\d{2}-\d{2}$') {
    $ExportDate = [DateTime]::Parse($DateOverride)
} elseif ($args.Count -gt 0 -and $args[0] -match '^\d{4}-\d{2}-\d{2}$') {
    $ExportDate = [DateTime]::Parse($args[0])
}

$DateStr = $ExportDate.ToString("yyyy-MM-dd")
$StartTime = $ExportDate.Date.AddHours($WORK_START_HOUR).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
$EndTime = $ExportDate.Date.AddHours($WORK_END_HOUR).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")

Write-Host "ES Express Activity Export" -ForegroundColor Cyan
Write-Host "Employee: $EMPLOYEE_NAME"
Write-Host "Date: $DateStr ($WORK_START_HOUR`:00 - $WORK_END_HOUR`:00)"
Write-Host ""

# ─── Helper: Call ActivityWatch API ──────────────────────────────────────────

function Invoke-AW {
    param([string]$Path)
    try {
        $response = Invoke-RestMethod -Uri "$AW_BASE_URL$Path" -TimeoutSec 5 -ErrorAction Stop
        return $response
    } catch {
        return $null
    }
}

# ─── Check ActivityWatch is running ──────────────────────────────────────────

$info = Invoke-AW "/info"
if (-not $info) {
    Write-Host "ERROR: ActivityWatch is not running on localhost:5600" -ForegroundColor Red
    Write-Host "Please start ActivityWatch and try again." -ForegroundColor Yellow
    if (-not $Silent) { Read-Host "Press Enter to exit" }
    exit 1
}
Write-Host "Connected to ActivityWatch v$($info.version)" -ForegroundColor Green

# ─── Discover buckets ───────────────────────────────────────────────────────

$buckets = Invoke-AW "/buckets"
if (-not $buckets) {
    Write-Host "ERROR: Could not fetch buckets" -ForegroundColor Red
    exit 1
}

$hostname = $info.hostname
$windowBucket = ($buckets.PSObject.Properties | Where-Object { $_.Name -like "aw-watcher-window_*" } | Select-Object -First 1)?.Name
$afkBucket = ($buckets.PSObject.Properties | Where-Object { $_.Name -like "aw-watcher-afk_*" } | Select-Object -First 1)?.Name
$webBucket = ($buckets.PSObject.Properties | Where-Object { $_.Name -like "aw-watcher-web-*" } | Select-Object -First 1)?.Name

Write-Host "Buckets found:"
if ($windowBucket) { Write-Host "  Window: $windowBucket" -ForegroundColor Green }
else { Write-Host "  Window: NOT FOUND" -ForegroundColor Yellow }
if ($afkBucket) { Write-Host "  AFK: $afkBucket" -ForegroundColor Green }
else { Write-Host "  AFK: NOT FOUND" -ForegroundColor Yellow }
if ($webBucket) { Write-Host "  Web: $webBucket" -ForegroundColor Green }
else { Write-Host "  Web: NOT FOUND" -ForegroundColor Yellow }
Write-Host ""

# ─── Fetch events from each bucket ──────────────────────────────────────────

function Get-BucketEvents {
    param([string]$BucketId)
    if (-not $BucketId) { return @() }
    $encoded = [System.Uri]::EscapeDataString($BucketId)
    $events = Invoke-AW "/buckets/$encoded/events?start=$StartTime&end=$EndTime&limit=-1"
    if ($events) { return $events } else { return @() }
}

Write-Host "Fetching activity data..." -ForegroundColor Cyan
$windowEvents = Get-BucketEvents $windowBucket
$afkEvents = Get-BucketEvents $afkBucket
$webEvents = Get-BucketEvents $webBucket

Write-Host "  Window events: $($windowEvents.Count)"
Write-Host "  AFK events: $($afkEvents.Count)"
Write-Host "  Web events: $($webEvents.Count)"
Write-Host ""

# ─── Process window events → app summary ─────────────────────────────────────

$appTotals = @{}
$titleDetails = @{}

foreach ($evt in $windowEvents) {
    $dur = [double]$evt.duration
    $app = $evt.data.app
    $title = $evt.data.title
    if (-not $app) { continue }

    if (-not $appTotals.ContainsKey($app)) { $appTotals[$app] = 0.0 }
    $appTotals[$app] += $dur

    $key = "$app|$title"
    if (-not $titleDetails.ContainsKey($key)) { $titleDetails[$key] = 0.0 }
    $titleDetails[$key] += $dur
}

# Sort apps by time descending
$sortedApps = $appTotals.GetEnumerator() | Sort-Object -Property Value -Descending

# ─── Process AFK events → active/idle time ───────────────────────────────────

$activeSeconds = 0.0
$idleSeconds = 0.0

foreach ($evt in $afkEvents) {
    $dur = [double]$evt.duration
    if ($evt.data.status -eq "not-afk") {
        $activeSeconds += $dur
    } else {
        $idleSeconds += $dur
    }
}

$totalTracked = $activeSeconds + $idleSeconds

# ─── Process web events → site summary ───────────────────────────────────────

$siteTotals = @{}

foreach ($evt in $webEvents) {
    $dur = [double]$evt.duration
    $url = $evt.data.url
    if (-not $url) { continue }

    try {
        $uri = [System.Uri]$url
        $domain = $uri.Host
    } catch {
        $domain = $url
    }

    if (-not $siteTotals.ContainsKey($domain)) { $siteTotals[$domain] = 0.0 }
    $siteTotals[$domain] += $dur
}

$sortedSites = $siteTotals.GetEnumerator() | Sort-Object -Property Value -Descending

# ─── Build hourly timeline ───────────────────────────────────────────────────

$hourlyActive = @{}
for ($h = $WORK_START_HOUR; $h -lt $WORK_END_HOUR; $h++) {
    $hourlyActive[$h] = 0.0
}

foreach ($evt in $windowEvents) {
    $evtStart = [DateTimeOffset]::Parse($evt.timestamp).LocalDateTime
    $dur = [double]$evt.duration
    $evtEnd = $evtStart.AddSeconds($dur)

    for ($h = $WORK_START_HOUR; $h -lt $WORK_END_HOUR; $h++) {
        $hourStart = $ExportDate.Date.AddHours($h)
        $hourEnd = $ExportDate.Date.AddHours($h + 1)

        # Calculate overlap
        $overlapStart = [Math]::Max($evtStart.Ticks, $hourStart.Ticks)
        $overlapEnd = [Math]::Min($evtEnd.Ticks, $hourEnd.Ticks)
        if ($overlapEnd -gt $overlapStart) {
            $overlapSeconds = ([TimeSpan]::new($overlapEnd - $overlapStart)).TotalSeconds
            $hourlyActive[$h] += $overlapSeconds
        }
    }
}

# ─── Helper: format seconds ─────────────────────────────────────────────────

function Format-Duration {
    param([double]$Seconds)
    $ts = [TimeSpan]::FromSeconds($Seconds)
    if ($ts.TotalHours -ge 1) {
        return "{0}h {1}m" -f [int]$ts.TotalHours, $ts.Minutes
    } elseif ($ts.TotalMinutes -ge 1) {
        return "{0}m" -f [int]$ts.TotalMinutes
    } else {
        return "{0}s" -f [int]$ts.TotalSeconds
    }
}

# ─── Generate HTML report ────────────────────────────────────────────────────

$reportFile = Join-Path $REPORT_DIR "activity-report-$($EMPLOYEE_NAME)-$DateStr.html"

$appRows = ""
foreach ($app in $sortedApps) {
    $pct = if ($totalTracked -gt 0) { [math]::Round(($app.Value / $totalTracked) * 100, 1) } else { 0 }
    $barWidth = [math]::Min($pct, 100)
    $appRows += @"
    <tr>
        <td>$($app.Key)</td>
        <td>$(Format-Duration $app.Value)</td>
        <td>
            <div class="bar-bg"><div class="bar" style="width:${barWidth}%"></div></div>
            ${pct}%
        </td>
    </tr>
"@
}

$siteRows = ""
$siteCount = 0
foreach ($site in $sortedSites) {
    if ($siteCount -ge 25) { break }
    $siteRows += @"
    <tr>
        <td>$($site.Key)</td>
        <td>$(Format-Duration $site.Value)</td>
    </tr>
"@
    $siteCount++
}

$timelineRows = ""
for ($h = $WORK_START_HOUR; $h -lt $WORK_END_HOUR; $h++) {
    $mins = [math]::Round($hourlyActive[$h] / 60, 0)
    $barWidth = [math]::Min([math]::Round(($hourlyActive[$h] / 3600) * 100, 0), 100)
    $color = if ($mins -ge 45) { "#22c55e" } elseif ($mins -ge 20) { "#f59e0b" } else { "#ef4444" }
    $label = if ($h -lt 12) { "${h} AM" } elseif ($h -eq 12) { "12 PM" } else { "$($h-12) PM" }
    $timelineRows += @"
    <tr>
        <td>$label</td>
        <td>
            <div class="bar-bg"><div class="bar" style="width:${barWidth}%; background:${color}"></div></div>
        </td>
        <td>${mins} min</td>
    </tr>
"@
}

$html = @"
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Activity Report — $EMPLOYEE_NAME — $DateStr</title>
<style>
    body { font-family: 'Segoe UI', Tahoma, sans-serif; max-width: 900px; margin: 40px auto; padding: 0 20px; background: #0f172a; color: #e2e8f0; }
    h1 { color: #f8fafc; border-bottom: 2px solid #334155; padding-bottom: 12px; }
    h2 { color: #94a3b8; margin-top: 32px; }
    .summary { display: flex; gap: 24px; margin: 20px 0; }
    .stat { background: #1e293b; border-radius: 8px; padding: 16px 24px; flex: 1; }
    .stat .label { color: #64748b; font-size: 13px; text-transform: uppercase; letter-spacing: 0.5px; }
    .stat .value { font-size: 28px; font-weight: 700; color: #f8fafc; margin-top: 4px; }
    .stat .value.green { color: #22c55e; }
    .stat .value.amber { color: #f59e0b; }
    .stat .value.red { color: #ef4444; }
    table { width: 100%; border-collapse: collapse; margin: 12px 0; }
    th { text-align: left; padding: 8px 12px; background: #1e293b; color: #94a3b8; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; }
    td { padding: 8px 12px; border-bottom: 1px solid #1e293b; }
    .bar-bg { display: inline-block; width: 120px; height: 12px; background: #1e293b; border-radius: 6px; vertical-align: middle; margin-right: 8px; }
    .bar { height: 100%; background: #3b82f6; border-radius: 6px; }
    .footer { margin-top: 40px; padding-top: 16px; border-top: 1px solid #334155; color: #475569; font-size: 12px; }
    .tag { display: inline-block; background: #1e293b; color: #94a3b8; padding: 2px 8px; border-radius: 4px; font-size: 12px; margin-right: 4px; }
</style>
</head>
<body>

<h1>Activity Report</h1>
<p><span class="tag">$EMPLOYEE_NAME</span> <span class="tag">$DateStr</span> <span class="tag">${WORK_START_HOUR}:00 - ${WORK_END_HOUR}:00</span></p>

<div class="summary">
    <div class="stat">
        <div class="label">Active Time</div>
        <div class="value green">$(Format-Duration $activeSeconds)</div>
    </div>
    <div class="stat">
        <div class="label">Idle Time</div>
        <div class="value amber">$(Format-Duration $idleSeconds)</div>
    </div>
    <div class="stat">
        <div class="label">Total Tracked</div>
        <div class="value">$(Format-Duration $totalTracked)</div>
    </div>
    <div class="stat">
        <div class="label">Active Rate</div>
        <div class="value $(if ($totalTracked -gt 0 -and ($activeSeconds/$totalTracked) -ge 0.7) {'green'} elseif ($totalTracked -gt 0 -and ($activeSeconds/$totalTracked) -ge 0.5) {'amber'} else {'red'})">$(if ($totalTracked -gt 0) { "{0}%" -f [math]::Round(($activeSeconds / $totalTracked) * 100, 0) } else { "N/A" })</div>
    </div>
</div>

<h2>Hourly Timeline</h2>
<table>
    <tr><th>Hour</th><th>Activity</th><th>Minutes</th></tr>
    $timelineRows
</table>

<h2>Applications</h2>
<table>
    <tr><th>Application</th><th>Time</th><th>Share</th></tr>
    $appRows
</table>

<h2>Top Websites</h2>
<table>
    <tr><th>Domain</th><th>Time</th></tr>
    $siteRows
</table>

<div class="footer">
    Generated by ES Express Activity Tracker on $(Get-Date -Format "yyyy-MM-dd HH:mm") | ActivityWatch v$($info.version) | Data from local machine only
</div>

</body>
</html>
"@

$html | Out-File -FilePath $reportFile -Encoding UTF8

Write-Host ""
Write-Host "Report saved: $reportFile" -ForegroundColor Green
Write-Host ""

# Also save a JSON version for programmatic review
$jsonReport = @{
    employee = $EMPLOYEE_NAME
    hostname = $hostname
    date = $DateStr
    work_hours = @{ start = $WORK_START_HOUR; end = $WORK_END_HOUR }
    summary = @{
        active_seconds = [math]::Round($activeSeconds, 0)
        idle_seconds = [math]::Round($idleSeconds, 0)
        total_seconds = [math]::Round($totalTracked, 0)
        active_rate = if ($totalTracked -gt 0) { [math]::Round($activeSeconds / $totalTracked, 3) } else { 0 }
    }
    applications = @($sortedApps | ForEach-Object { @{ name = $_.Key; seconds = [math]::Round($_.Value, 0) } })
    websites = @($sortedSites | ForEach-Object { @{ domain = $_.Key; seconds = [math]::Round($_.Value, 0) } })
    hourly = @(for ($h = $WORK_START_HOUR; $h -lt $WORK_END_HOUR; $h++) {
        @{ hour = $h; active_seconds = [math]::Round($hourlyActive[$h], 0) }
    })
    generated_at = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
} | ConvertTo-Json -Depth 4

$jsonFile = Join-Path $REPORT_DIR "activity-report-$($EMPLOYEE_NAME)-$DateStr.json"
$jsonReport | Out-File -FilePath $jsonFile -Encoding UTF8
Write-Host "JSON data: $jsonFile" -ForegroundColor Green

# Open the HTML report in default browser
Start-Process $reportFile

Write-Host ""
Write-Host "Please send the report file to Jessica for review." -ForegroundColor Yellow
Write-Host ""

# ─── Archive old reports ────────────────────────────────────────────────────

$ARCHIVE_DIR = "C:\ESExpress\ActivityTracker\archive"
if (Test-Path $ARCHIVE_DIR) {
    $cutoff = (Get-Date).AddDays(-7)
    $oldReports = Get-ChildItem -Path $REPORT_DIR -Filter "activity-report-*" -File -ErrorAction SilentlyContinue |
        Where-Object { $_.LastWriteTime -lt $cutoff }

    if ($oldReports.Count -gt 0) {
        foreach ($file in $oldReports) {
            Move-Item -Path $file.FullName -Destination $ARCHIVE_DIR -Force -ErrorAction SilentlyContinue
        }
        Write-Host "Archived $($oldReports.Count) old report(s) to $ARCHIVE_DIR" -ForegroundColor Gray
    }
}

if (-not $Silent) { Read-Host "Press Enter to exit" }
